import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  static const String _keyHistory = 'diet_history_porsipas';
  static const String _keyWater = 'water_count_porsipas';

  // Simpan hasil prediksi AI baru
  static Future<void> saveDietRecord(Map<String, dynamic> record) async {
    final prefs = await SharedPreferences.getInstance();
    List<String> history = prefs.getStringList(_keyHistory) ?? [];
    
    history.add(jsonEncode(record));
    await prefs.setStringList(_keyHistory, history);
  }

  // Ambil semua riwayat prediksi AI
  static Future<List>> getDietHistory() async {
    final prefs = await SharedPreferences.getInstance();
    List<String> history = prefs.getStringList(_keyHistory) ?? [];

    return history.map((item) {
      return Map<String, dynamic>.from(jsonDecode(item));
    }).toList();
  }

  // Hapus semua riwayat
  static Future<void> clearHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_keyHistory);
  }

  // Simpan data hidrasi air minum (dalam gelas)
  static Future<void> saveWaterCount(int count) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_keyWater, count);
  }

  // Ambil data hidrasi air minum
  static Future<int> getWaterCount() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_keyWater) ?? 0;
  }
}