import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';
import '../models/diet_model.dart';

class ApiService {
  static Future<DietResponse> getDietRecommendation(DietRequest request) async {
    final url = Uri.parse(ApiConfig.predictEndpoint);

    try {
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'ngrok-skip-browser-warning': 'true',
        },
        body: jsonEncode(request.toJson()),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        return DietResponse.fromJson(data);
      } else {
        throw Exception('Server Error Code: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Gagal terhubung ke backend: $e');
    }
  }

  // Fungsi Regenerate Alternatif Menu
  static Future<MealDetail> regenerateSingleMeal({
    required String waktuMakan,
    required String targetTubuh,
  }) async {
    final url = Uri.parse(ApiConfig.regenerateMenuEndpoint);

    try {
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'ngrok-skip-browser-warning': 'true',
        },
        body: jsonEncode({
          'waktu_makan': waktuMakan,
          'target_tubuh': targetTubuh,
        }),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        return MealDetail.fromJson(data);
      } else {
        throw Exception('Gagal mengganti menu');
      }
    } catch (e) {
      throw Exception('Koneksi gagal: $e');
    }
  }
}