import 'package:flutter/material.dart';
import '../services/storage_service.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List> _historyList = [];
  bool _isLoading = true;

  static const Color primaryGreen = Color(0xFF047857);
  static const Color emeraldGreen = Color(0xFF10B981);
  static const Color darkText = Color(0xFF1F2937);

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    setState(() => _isLoading = true);
    final data = await StorageService.getDietHistory();
    setState(() {
      _historyList = data.reversed.toList(); // Tampilkan dari yang terbaru
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFA),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: const Text(
          'Riwayat & Progres',
          style: TextStyle(
            color: primaryGreen,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_outline_rounded, color: Colors.redAccent),
            onPressed: () async {
              await StorageService.clearHistory();
              _loadHistory();
            },
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: primaryGreen))
          : _historyList.isEmpty
              ? const Center(
                  child: Text(
                    'Belum ada riwayat perhitungan.',
                    style: TextStyle(color: Colors.black54),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _historyList.length,
                  itemBuilder: (context, index) {
                    final item = _historyList[index];
                    return _buildHistoryCard(item);
                  },
                ),
    );
  }

  Widget _buildHistoryCard(Map<String, dynamic> item) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: ExpansionTile(
        tilePadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: const Color(0xFFECFDF5),
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Icon(Icons.analytics_outlined, color: primaryGreen),
        ),
        title: Text(
          '${item['kalori']} Kkal / Hari',
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: darkText),
        ),
        subtitle: Text(
          '${item['status']} • BB: ${item['berat']} kg',
          style: const TextStyle(fontSize: 12, color: Colors.black54),
        ),
        childrenPadding: const EdgeInsets.all(16),
        children: [
          const Divider(),
          _infoRow('Tinggi Badan', '${item['tinggi']} cm'),
          _infoRow('Umur', '${item['umur']} Tahun'),
          _infoRow('Status AI', '${item['status']}'),
          const SizedBox(height: 8),
          const Text(
            'Rekomendasi Menu:',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: primaryGreen),
          ),
          const SizedBox(height: 4),
          Text('• Sarapan: ${item['menu_sarapan']}', style: const TextStyle(fontSize: 12)),
          Text('• Siang: ${item['menu_siang']}', style: const TextStyle(fontSize: 12)),
          Text('• Malam: ${item['menu_malam']}', style: const TextStyle(fontSize: 12)),
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontSize: 12, color: Colors.black54)),
          Text(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}