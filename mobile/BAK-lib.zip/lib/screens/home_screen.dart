import 'package:flutter/material.dart';
import '../services/storage_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Map<String, dynamic>? _lastRecord;
  int _waterCount = 0;
  bool _isLoading = true;

  static const Color primaryGreen = Color(0xFF047857);
  static const Color emeraldGreen = Color(0xFF10B981);
  static const Color darkText = Color(0xFF1F2937);

  @override
  void initState() {
    super.initState();
    _loadDashboardData();
  }

  Future<void> _loadDashboardData() async {
    setState(() => _isLoading = true);
    final history = await StorageService.getDietHistory();
    final water = await StorageService.getWaterCount();

    setState(() {
      _lastRecord = history.isNotEmpty ? history.last : null;
      _waterCount = water;
      _isLoading = false;
    });
  }

  Future<void> _updateWater(int delta) async {
    int newCount = _waterCount + delta;
    if (newCount < 0) newCount = 0;
    if (newCount > 12) newCount = 12;

    await StorageService.saveWaterCount(newCount);
    setState(() => _waterCount = newCount);
  }

  String _getGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 11) return 'Selamat Pagi ☀️';
    if (hour < 15) return 'Selamat Siang 🌤️';
    if (hour < 18) return 'Selamat Sore ⛅';
    return 'Selamat Malam 🌙';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFA),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [primaryGreen, emeraldGreen],
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.eco, color: Colors.white, size: 20),
            ),
            const SizedBox(width: 8),
            const Text(
              'PorsiPas',
              style: TextStyle(
                color: primaryGreen,
                fontWeight: FontWeight.w900,
                fontSize: 20,
              ),
            ),
            Container(
              margin: const EdgeInsets.only(left: 6),
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: Colors.orange.shade50,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: Colors.orange.shade200),
              ),
              child: const Text(
                'AI',
                style: TextStyle(
                  color: Colors.orange,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: Colors.black54),
            onPressed: _loadDashboardData,
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: primaryGreen))
          : SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _getGreeting(),
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      color: darkText,
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Pantau kebutuhan nutrisi & rekomendasi sehatmu.',
                    style: TextStyle(color: Colors.black54, fontSize: 13),
                  ),
                  const SizedBox(height: 20),

                  // Hero Card: Target Kalori & Status AI
                  _buildHeroCard(),
                  const SizedBox(height: 16),

                  // Card Hidrasi
                  _buildWaterCard(),
                  const SizedBox(height: 20),

                  // Makronutrisi
                  if (_lastRecord != null) ...[
                    _buildMacroCard(),
                    const SizedBox(height: 24),
                  ],

                  // Menu AI
                  const Row(
                    children: [
                      Icon(Icons.restaurant_menu_rounded, color: primaryGreen),
                      SizedBox(width: 8),
                      Text(
                        'Rekomendasi Menu AI',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                          color: darkText,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  if (_lastRecord == null)
                    _buildEmptyMenuCard()
                  else ...[
                    _buildMealItem('Sarapan', _lastRecord!['menu_sarapan'], Icons.wb_sunny_outlined, Colors.orange),
                    _buildMealItem('Makan Siang', _lastRecord!['menu_siang'], Icons.wb_sunny, primaryGreen),
                    _buildMealItem('Makan Malam', _lastRecord!['menu_malam'], Icons.nightlight_round, Colors.indigo),
                  ],

                  const SizedBox(height: 24),

                  // Panduan Isi Piringku
                  _buildPiringkuGuide(),
                  const SizedBox(height: 20),
                ],
              ),
            ),
    );
  }

  Widget _buildHeroCard() {
    final kalori = _lastRecord != null ? _lastRecord!['kalori'] : '—';
    final status = _lastRecord != null ? _lastRecord!['status'] : 'Belum Ada Data';

    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [primaryGreen, Color(0xFF065F46)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: primaryGreen.withOpacity(0.3),
            blurRadius: 14,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '$kalori',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 34,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const Text(
                  'Kkal Target Harian',
                  style: TextStyle(color: Colors.white70, fontSize: 13),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white30),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.auto_awesome, color: Colors.amberAccent, size: 14),
                const SizedBox(width: 6),
                Text(
                  '$status',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWaterCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFFEFF6FF),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(Icons.water_drop_rounded, color: Color(0xFF2563EB), size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Hidrasi Hari Ini',
                  style: TextStyle(fontSize: 12, color: Colors.black54, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 2),
                Text(
                  '$_waterCount / 8 Gelas',
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: darkText),
                ),
              ],
            ),
          ),
          Row(
            children: [
              IconButton(
                icon: const Icon(Icons.remove_circle_outline, color: Colors.grey),
                onPressed: () => _updateWater(-1),
              ),
              IconButton(
                icon: const Icon(Icons.add_circle, color: emeraldGreen),
                onPressed: () => _updateWater(1),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMacroCard() {
    final karbo = _lastRecord?['makro_karbo'] ?? 50;
    final protein = _lastRecord?['makro_protein'] ?? 25;
    final lemak = _lastRecord?['makro_lemak'] ?? 25;

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Proposi Makronutrisi (Dari AI)',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: darkText),
          ),
          const SizedBox(height: 14),
          _macroBar('Karbohidrat', karbo, Colors.blue),
          const SizedBox(height: 8),
          _macroBar('Protein', protein, Colors.redAccent),
          const SizedBox(height: 8),
          _macroBar('Lemak Sehat', lemak, Colors.amber.shade700),
        ],
      ),
    );
  }

  Widget _macroBar(String title, dynamic percent, Color color) {
    double val = (percent is num) ? percent.toDouble() : 0.0;
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(title, style: const TextStyle(fontSize: 12, color: Colors.black87)),
            Text('${val.toInt()}%', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
          ],
        ),
        const SizedBox(height: 4),
        LinearProgressIndicator(
          value: val / 100,
          color: color,
          backgroundColor: Colors.grey.shade100,
          minHeight: 6,
          borderRadius: BorderRadius.circular(3),
        ),
      ],
    );
  }

  Widget _buildMealItem(String title, dynamic menuName, IconData icon, Color color) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(fontSize: 11, color: color, fontWeight: FontWeight.bold)),
                const SizedBox(height: 2),
                Text(
                  menuName?.toString() ?? 'Menu belum tersedia',
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: darkText),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyMenuCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: const Center(
        child: Text(
          'Belum ada rekomendasi menu. Buka tab "Buat Rencana" untuk memproses data dengan AI.',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.black54, fontSize: 13),
        ),
      ),
    );
  }

  Widget _buildPiringkuGuide() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Row(
          children: [
            Icon(Icons.pie_chart_outline_rounded, color: primaryGreen),
            SizedBox(width: 8),
            Text(
              'Panduan Isi Piringku',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: darkText),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(child: _piringTile('Makanan Pokok', 'Sumber Energi', Colors.amber.shade50, Colors.amber.shade900)),
            const SizedBox(width: 10),
            Expanded(child: _piringTile('Lauk Pauk', 'Sumber Protein', Colors.emerald.shade50, primaryGreen)),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(child: _piringTile('Sayuran', 'Serat & Vitamin', Colors.emerald.shade50, primaryGreen)),
            const SizedBox(width: 10),
            Expanded(child: _piringTile('Buah-buahan', 'Mineral', Colors.purple.shade50, Colors.purple.shade900)),
          ],
        ),
      ],
    );
  }

  Widget _piringTile(String title, String sub, Color bg, Color textCol) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(14)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: TextStyle(fontWeight: FontWeight.bold, color: textCol, fontSize: 12)),
          const SizedBox(height: 2),
          Text(sub, style: TextStyle(fontSize: 10, color: textCol.withOpacity(0.8))),
        ],
      ),
    );
  }
}