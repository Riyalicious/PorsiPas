import 'package:flutter/material.dart';
import '../models/diet_model.dart';
import '../services/api_service.dart';
import '../services/storage_service.dart';

class FormScreen extends StatefulWidget {
  const FormScreen({super.key});

  @override
  State<FormScreen> createState() => _FormScreenState();
}

class _FormScreenState extends State<FormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _umurController = TextEditingController();
  final _tinggiController = TextEditingController();
  final _beratController = TextEditingController();

  String _jenisKelamin = 'Pria';
  String _targetTubuh = 'Turunkan Berat';
  int _frekuensiOlahraga = 2;

  void _showAILoadingDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return Dialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Stack(
                  alignment: Alignment.center,
                  children: [
                    const SizedBox(
                      width: 60, height: 60,
                      child: CircularProgressIndicator(color: Colors.green, strokeWidth: 6),
                    ),
                    Icon(Icons.auto_awesome, color: Colors.green[800], size: 30),
                  ],
                ),
                const SizedBox(height: 24),
                const Text(
                  'Menganalisis Genetik & Postur...',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),
                const Text(
                  'Model Machine Learning sedang meracik menu terbaik untukmu 🥗',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 13, color: Colors.grey),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _submitData() async {
    if (!_formKey.currentState!.validate()) return;
    _showAILoadingDialog();
    
    try {
      String targetApi = 'sedang';
      if (_targetTubuh == 'Turunkan Berat') {
        targetApi = 'kurus';
      } else if (_targetTubuh == 'Naikkan Berat') {
        targetApi = 'bulky';
      } else if (_targetTubuh == 'Membentuk Otot') {
        targetApi = 'berotot';
      }

      final requestData = DietRequest(
        umur: int.parse(_umurController.text),
        tinggi: double.parse(_tinggiController.text),
        berat: double.parse(_beratController.text),
        frekuensiOlahraga: _frekuensiOlahraga,
        jenisKelamin: _jenisKelamin.toLowerCase(),
        targetTubuh: targetApi,
      );

      final dietResponse = await ApiService.getDietRecommendation(requestData);

      if (mounted) Navigator.pop(context); // Tutup Loading Dialog

      // Simpan data lengkap beserta Makronutrisi dari AI ke Storage Local
      Map<String, dynamic> record = {
        'tanggal': DateTime.now().toString(),
        'berat': double.parse(_beratController.text),
        'tinggi': double.parse(_tinggiController.text),
        'kalori': dietResponse.kaloriHarian,
        'status': dietResponse.kategoriDiet.isNotEmpty ? dietResponse.kategoriDiet : _targetTubuh,
        'target': _targetTubuh,
        
        // --- INI ADALAH 3 BARIS BARU YANG DITAMBAHKAN ---
        'umur': int.parse(_umurController.text),
        'kelamin': _jenisKelamin,
        'olahraga': _frekuensiOlahraga,
        // ------------------------------------------------

        'menu_sarapan': dietResponse.rekomendasiMakanan.sarapan.menu,
        'menu_siang': dietResponse.rekomendasiMakanan.makanSiang.menu,
        'menu_malam': dietResponse.rekomendasiMakanan.makanMalam.menu,
        'makro_karbo': dietResponse.makronutrisi.karboPersen,
        'makro_protein': dietResponse.makronutrisi.proteinPersen,
        'makro_lemak': dietResponse.makronutrisi.lemakPersen,
      };

      await StorageService.saveHistoryRecord(record);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Rekomendasi AI berhasil dibuat & disimpan!'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (mounted) Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal terhubung ke server: $e'), backgroundColor: Colors.red),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            // HEADER CUSTOM DENGAN GRADIEN
            Container(
              width: double.infinity,
              padding: const EdgeInsets.only(top: 60, bottom: 30, left: 20, right: 20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.green[900]!, Colors.green[600]!],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(30),
                  bottomRight: Radius.circular(30),
                ),
              ),
              child: const Column(
                children: [
                  Icon(Icons.psychology, size: 70, color: Colors.white),
                  SizedBox(height: 12),
                  Text(
                    'Asisten Diet AI',
                    style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Biar AI yang pusing menghitung kalori,\nkamu tinggal fokus makan sehat!',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white70, fontSize: 14),
                  ),
                ],
              ),
            ),
            
            // FORM INPUT
            Padding(
              padding: const EdgeInsets.all(20),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    DropdownButtonFormField<String>(
                      value: _jenisKelamin,
                      decoration: const InputDecoration(
                        labelText: 'Jenis Kelamin', border: OutlineInputBorder(), prefixIcon: Icon(Icons.wc),
                      ),
                      items: ['Pria', 'Wanita'].map((String value) {
                        return DropdownMenuItem<String>(value: value, child: Text(value));
                      }).toList(),
                      onChanged: (newValue) => setState(() => _jenisKelamin = newValue!),
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _umurController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Umur (Tahun)', 
                        border: OutlineInputBorder(), 
                        prefixIcon: Icon(Icons.person),
                      ),
                      validator: (val) {
                        if (val == null || val.isEmpty) return 'Wajib diisi';
                        final umur = int.tryParse(val);
                        if (umur == null) return 'Harus berupa angka';
                        if (umur < 12 || umur > 100) return 'Umur harus antara 12 - 100 tahun';
                        return null;
                      },
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _tinggiController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Tinggi Badan (cm)', 
                        border: OutlineInputBorder(), 
                        prefixIcon: Icon(Icons.height),
                      ),
                      validator: (val) {
                        if (val == null || val.isEmpty) return 'Wajib diisi';
                        final tinggi = double.tryParse(val);
                        if (tinggi == null) return 'Harus berupa angka';
                        if (tinggi < 100 || tinggi > 250) return 'Tinggi harus antara 100 - 250 cm';
                        return null;
                      },
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _beratController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Berat Badan (kg)', 
                        border: OutlineInputBorder(), 
                        prefixIcon: Icon(Icons.monitor_weight),
                      ),
                      validator: (val) {
                        if (val == null || val.isEmpty) return 'Wajib diisi';
                        final berat = double.tryParse(val);
                        if (berat == null) return 'Harus berupa angka';
                        if (berat < 30 || berat > 300) return 'Berat harus antara 30 - 300 kg';
                        return null;
                      },
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<int>(
                      value: _frekuensiOlahraga,
                      decoration: const InputDecoration(
                        labelText: 'Frekuensi Olahraga', border: OutlineInputBorder(), prefixIcon: Icon(Icons.fitness_center),
                      ),
                      items: const [
                        DropdownMenuItem(value: 0, child: Text('Jarang / Tidak Pernah')),
                        DropdownMenuItem(value: 1, child: Text('1-2x / Minggu (Ringan)')),
                        DropdownMenuItem(value: 2, child: Text('3-5x / Minggu (Sedang)')),
                        DropdownMenuItem(value: 3, child: Text('Setiap Hari (Berat)')),
                      ],
                      onChanged: (newValue) => setState(() => _frekuensiOlahraga = newValue!),
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      value: _targetTubuh,
                      decoration: const InputDecoration(
                        labelText: 'Target Tubuh', border: OutlineInputBorder(), prefixIcon: Icon(Icons.track_changes),
                      ),
                      items: ['Turunkan Berat', 'Pertahankan', 'Naikkan Berat', 'Membentuk Otot'].map((String value) {
                        return DropdownMenuItem<String>(value: value, child: Text(value));
                      }).toList(),
                      onChanged: (newValue) => setState(() => _targetTubuh = newValue!),
                    ),
                    const SizedBox(height: 24),
                    ElevatedButton.icon(
                      onPressed: _submitData,
                      icon: const Icon(Icons.auto_awesome),
                      label: const Text('PROSES DENGAN MODEL AI'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green[800],
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}