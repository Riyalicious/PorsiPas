class ApiConfig {
  // Base URL Ngrok terpusat
  static const String baseUrl = 'https://regulate-subsoil-booted.ngrok-free.dev';

  // Endpoints
  static const String predictEndpoint = '$baseUrl/api/v1/predict';
  static const String regenerateMenuEndpoint = '$baseUrl/api/v1/regenerate-menu';
}